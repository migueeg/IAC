// Importamos el módulo pg para conectarnos a PostgreSQL
const { Pool } = require('pg');

// Log inicial para verificar que la Lambda se está ejecutando
console.log('Lambda iniciando...');

// Log de variables de entorno (sin mostrar passwords)
console.log('Variables de entorno:', {
  DB_HOST: process.env.DB_HOST,
  DB_NAME: process.env.DB_NAME,
  DB_USER: process.env.DB_USER
});

const pool = new Pool({
  host: process.env.DB_HOST ? process.env.DB_HOST.split(':')[0] : null,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  port: 5432,
  ssl: {
    rejectUnauthorized: false
  }
});

exports.handler = async (event) => {
  let client;
  const recurso = '/login';
  const metodo = event.httpMethod || 'POST';
  const fecha = new Date().toISOString();

  try {
    // Log del evento recibido
    console.log(`[INFO] [${fecha}] Recurso: ${recurso} | Método: ${metodo} | Acción: Petición recibida`);

    // Validación del body
    if (!event.body) {
      console.warn(`[WARN] [${fecha}] Recurso: ${recurso} | Método: ${metodo} | Acción: No se recibió body en la petición`);
      throw new Error('No se recibió body en la petición');
    }

    // Establecemos conexión con la base de datos
    console.log(`[INFO] [${fecha}] Recurso: ${recurso} | Método: ${metodo} | Acción: Intentando conectar a la base de datos...`);
    client = await pool.connect();
    console.log(`[INFO] [${fecha}] Recurso: ${recurso} | Método: ${metodo} | Acción: Conexión exitosa a la base de datos`);

    const { username, password } = JSON.parse(event.body);
    console.log(`[INFO] [${fecha}] Recurso: ${recurso} | Método: ${metodo} | Usuario: ${username} | Acción: Datos de login recibidos`);

    const query = 'SELECT id, username FROM users WHERE username = $1 AND password = $2';
    const result = await client.query(query, [username, password]);
    console.log(`[INFO] [${fecha}] Recurso: ${recurso} | Método: ${metodo} | Usuario: ${username} | Acción: Consulta ejecutada | Resultados: ${result.rows.length}`);

    if (result.rows.length > 0) {
      console.log(`[INFO] [${fecha}] Recurso: ${recurso} | Método: ${metodo} | Usuario: ${username} | Acción: Usuario logeado correctamente`);
    } else {
      console.warn(`[WARN] [${fecha}] Recurso: ${recurso} | Método: ${metodo} | Usuario: ${username} | Acción: Intento de acceso fallido`);
    }

    return {
      statusCode: result.rows.length > 0 ? 200 : 401,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        message: result.rows.length > 0 ? 'Usuario logeado correctamente' : 'Usuario o contraseña incorrectos',
        user: result.rows[0]
      })
    };
  } catch (error) {
    console.error(`[ERROR] [${fecha}] Recurso: ${recurso} | Método: ${metodo} | Acción: Error en el proceso de login | Detalle: ${error.message}`);

    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ 
        message: 'Error interno del servidor',
        error: error.message,
        type: error.name
      })
    };
  } finally {
    if (client) {
      try {
        await client.release();
        console.log(`[INFO] [${fecha}] Recurso: ${recurso} | Método: ${metodo} | Acción: Conexión liberada`);
      } catch (releaseError) {
        console.error(`[ERROR] [${fecha}] Recurso: ${recurso} | Método: ${metodo} | Acción: Error al liberar conexión | Detalle: ${releaseError.message}`);
      }
    }
  }
};