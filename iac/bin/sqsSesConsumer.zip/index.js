const AWS = require("aws-sdk");
const ses = new AWS.SES();

exports.handler = async (event) => {
  console.log("Inicio de procesamiento del evento:", JSON.stringify(event));

  for (const record of event.Records) {
    const messageBody = record.body;
    console.log("Procesando mensaje:", messageBody);

    const params = {
      Destination: {
        ToAddresses: [process.env.EMAIL_TO],
      },
      Message: {
        Body: {
          Text: {
            Data: `Nuevo mensaje recibido desde SQS:\n\n${messageBody}`,
          },
        },
        Subject: {
          Data: "Notificación desde Lambda + SQS + SES",
        },
      },
      Source: process.env.EMAIL_FROM,
    };

    try {
      const result = await ses.sendEmail(params).promise();
      console.log("Correo enviado con éxito. MessageId:", result.MessageId);
    } catch (error) {
      console.error("Error al enviar correo:", JSON.stringify(error, null, 2));
    }
  }

  return {
    statusCode: 200,
    body: "Proceso completado.",
  };
};
